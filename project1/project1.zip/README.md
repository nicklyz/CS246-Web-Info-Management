### Instruction
To generate the submission file, run:
```
zip -r project1.zip GetWebpage.java ParseJSON.java build.sh task3.txt README.md
```

To test the submission file, run:
```
./p1_test project1.zip
```
